package HealthDataHandling;


public class VitalSign {
    private long patientID;
    private int heartRate;
    private int oxygenLevel;
    private String bloodPressure;
    private double temperature;
    private String timestamp;  // date and time when vitals were recorded

    public VitalSign(long patientID, int heartRate, int oxygenLevel, String bloodPressure, double temperature, String timestamp) {
        this.patientID = patientID;
        this.heartRate = heartRate;
        this.oxygenLevel = oxygenLevel;
        this.bloodPressure = bloodPressure;
        this.temperature = temperature;
        this.timestamp = timestamp;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public long getPatientID() {
        return patientID;
    }

    public void setPatientID(long patientID) {
        this.patientID = patientID;
    }

    public int getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(int heartRate) {
        this.heartRate = heartRate;
    }

    public int getOxygenLevel() {
        return oxygenLevel;
    }

    public void setOxygenLevel(int oxygenLevel) {
        this.oxygenLevel = oxygenLevel;
    }

    public String getBloodPressure() {
        return bloodPressure;
    }

    public void setBloodPressure(String bloodPressure) {
        this.bloodPressure = bloodPressure;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    @Override
    public String toString() {
        return "PatientID: " + patientID + ", HeartRate: " + heartRate + ", OxygenLevel: " + oxygenLevel +
                ", BP: " + bloodPressure + ", Temp: " + temperature + ", Timestamp: " + timestamp;
    }
}
