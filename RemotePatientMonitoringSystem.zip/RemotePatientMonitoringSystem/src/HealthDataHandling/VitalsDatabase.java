package HealthDataHandling;

import UserManagement.Doctor;

import java.util.ArrayList;
import java.util.Scanner;

public class VitalsDatabase {

    private ArrayList<VitalSign> vitals = new ArrayList<>();
    Doctor doctor = new Doctor();

    public ArrayList<VitalSign> getVitals() {
        return vitals;
    }

    public void setVitals(ArrayList<VitalSign> vitals) {
        this.vitals = vitals;
    }

    public void storeVitalRecords() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter id of patient whose vitals were recorded: ");
        long patientID = scanner.nextLong();

        if (doctor.isValidID(patientID)) {
            System.out.print("Enter Heart Rate of patient(BPM): ");
            int heartRate = scanner.nextInt();
            System.out.print("Enter Oxygen Level of patient(%): ");
            int oxygenLevel = scanner.nextInt();

            scanner.nextLine();

            System.out.print("Enter Blood Pressure of patient(Systolic/Diastolic): ");
            String bloodPressure = scanner.nextLine();
            System.out.print("Enter Temperature of patient(°F): ");
            double temperature = scanner.nextDouble();

            scanner.nextLine();

            System.out.print("Enter timestamp at which patient details got recorded: ");
            String timestamp = scanner.nextLine();

            vitals.add(new VitalSign(patientID, heartRate, oxygenLevel, bloodPressure,
                    temperature, timestamp));
            System.out.println("Vitals recorded successfully!\n");
        }else {
            System.out.println("You have entered incorrect patientId. Plz enter correct one");
        }
    }

    public void retrieveVitalRecords() {
        System.out.println("\nTotal Vital Records Stored are " + vitals.size());
        int counter = 1;
        for (VitalSign vital: vitals) {
            System.out.println("\t" + (counter++) + ") " + vital.toString());
        }
        System.out.println();
    }
}
