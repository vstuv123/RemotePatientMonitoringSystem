import HealthDataHandling.VitalsDatabase;
import UserManagement.Administrator;
import UserManagement.Doctor;
import UserManagement.Patient;

public class Main {

    public static void main(String[] args) {

        Administrator administrator = new Administrator();
        administrator.addDoctor();
        administrator.addPatient();
        administrator.addPatient();

        administrator.getAllDoctorRecords();
        administrator.getAllPatientRecords();

        Patient patient = new Patient();
        patient.scheduleAppointment();

        Doctor doctor = new Doctor();
        doctor.provideFeedback();

        VitalsDatabase vitalsDatabase = new VitalsDatabase();
        vitalsDatabase.storeVitalRecords();
        vitalsDatabase.storeVitalRecords();

        vitalsDatabase.retrieveVitalRecords();
    }
}