package UserManagement;

import AppointmentScheduling.Appointment;
import AppointmentScheduling.AppointmentManager;
import DoctorPatientInteraction.Feedback;

import java.util.ArrayList;
import java.util.Scanner;

public class Doctor extends User {

    private static int feedBackArrayTracker = -1;
    Feedback feedback = new Feedback();
    Feedback[] feedbacksArray = feedback.getFeedbacks();
    Patient[] patients = (Patient[]) User.getRegisteredPatients();
    AppointmentManager am = new AppointmentManager();
    ArrayList<Appointment> appointments = am.getAppointments();
    Scanner scanner = new Scanner(System.in);

    public static int getFeedBackArrayTracker() {
        return feedBackArrayTracker;
    }

    public void patientsData() {
        int patientCount = User.getNoOfPatients();
        Patient[] patients = (Patient[]) User.getRegisteredPatients();

        System.out.println("\nTotal Patients: " + patientCount + "\n");

        for (int i = 0; i < patientCount; i++) {
            System.out.println("Patient Name: " + patients[i].getName());
            System.out.println("Patient Email: " + patients[i].getEmail());
            System.out.println("Patient Contact: " + patients[i].getContactNumber());
            System.out.println("Patient Address: " + patients[i].getAddress());
            System.out.println("Patient DOB: " + patients[i].getDob());
            System.out.println("Patient Health Data: \nHeartRate: " + patients[i].getHeartRate()
                    + ", Blood Pressure: " + patients[i].getBloodPressure() + ", Body Temperature: " +
                    patients[i].getBodyTemperature() + ", Respiratory Rate: " +
                    patients[i].getRespiratoryRate() + ", Blood Sugar Level: " +
                    patients[i].getBloodSugarLevel() + ", Weight: " + patients[i].getWeight()
                    + ", Height: " + patients[i].getHeight() + "\n");
        }
    }

    public boolean isValidID(long id) {
        for (int i = 0; i < User.getNoOfPatients(); i++) {
            if (patients[i].getUnique_id() == id) {
                return true;
            }
        }
        return false;
    }

    public void provideFeedback() {
        System.out.print("Please enter ID of patient to whom you want to give feedback: ");
        long patientID = scanner.nextLong();
        boolean validID = isValidID(patientID);
        scanner.nextLine();  // to clear buffer

        if (validID) {
            Feedback.setNoOfFeedbacks(Feedback.getNoOfFeedbacks() + 1);
            feedBackArrayTracker++;
            if (Feedback.getNoOfFeedbacks() == 51) {
                feedback.increaseArraySize();
                Feedback.setNoOfFeedbacks(0);
            }

            feedbacksArray[feedBackArrayTracker] = new Feedback();
            System.out.print("Please enter feedback: ");
            String notes = scanner.nextLine();
            feedbacksArray[feedBackArrayTracker].setNotes(notes);
            feedbacksArray[feedBackArrayTracker].setPatientID(patientID);
            feedbacksArray[feedBackArrayTracker].setDoctorID(this.getUnique_id());
            System.out.println("Feedback submitted successfully!\n");
        }else {
            System.out.println("You have entered incorrect Patient ID. Plz enter correct one");
        }
    }

    // Manage Appointments

    // doctor can see only details of his/her appointments
    public void doctorAppointmentDetails() {
        for (Appointment appointment : appointments) {
            if (appointment.getDoctorID() == this.getUnique_id()) {
                Doctor doctor = am.getDoctorById(appointment.getDoctorID());
                Patient patient = am.getPatientById(appointment.getPatientID());

                System.out.println("\nAppointment ID: " + appointment.getAppointmentID());
                System.out.println("Appointment Date: " + appointment.getDate());
                System.out.println("Doctor: " + (doctor != null ? doctor.getName() : "Not Found"));
                System.out.println("Patient: " + (patient != null ? patient.getName() : "Not Found"));
                System.out.println("Status: " + appointment.getStatus() + "\n");
            }
        }
    }

    public void approveAppointmentByDoctor() {
        System.out.println("Enter appointment Id: ");
        int appointmentID = scanner.nextInt();

        for (Appointment appointment: appointments) {
            if (appointment.getAppointmentID() == appointmentID && appointment.getStatus().equals("Pending")) {
                appointment.setStatus("Approved");
                System.out.println("Appointment approved successfully!");
                return;
            }
        }
        System.out.println("No pending appointment found for this doctor and patient.");
    }

    public String getDoctorName(long id) {
        StringBuilder name = new StringBuilder();
        Doctor[] doctors = (Doctor[]) User.getRegisteredDoctors();
        int doctorCount = User.getNoOfDoctors();

        for (int i = 0; i < doctorCount; i++) {
            if(doctors[i].getUnique_id() == id) {
                name.append(doctors[i].getName());
            }
        }
        return name.toString();
    }

    public void cancelAppointmentByDoctor() {
        System.out.println("Enter appointment Id: ");
        int appointmentID = scanner.nextInt();

        for (int i = 0; i < appointments.size(); i++) {
            if (appointments.get(i).getAppointmentID() == appointmentID) {
                appointments.remove(i);
                System.out.println("Appointment Cancelled Successfully");
                return;
            }
        }
        System.out.println("No Appointment Found with this ID");
    }
}
