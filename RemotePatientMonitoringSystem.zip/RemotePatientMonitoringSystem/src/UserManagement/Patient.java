package UserManagement;

import AppointmentScheduling.Appointment;
import AppointmentScheduling.AppointmentManager;
import DoctorPatientInteraction.Feedback;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Patient extends User {
    private int heartRate;  // Measured in beats per minute (BPM).
    private String bloodPressure;  // Stored as "Systolic/Diastolic" i.e. 120/80
    private double bodyTemperature;  // Measured in degrees Fahrenheit.
    private int respiratoryRate;  // Number of breaths per minute.
    private int bloodSugarLevel;  // Measured in mg/dL
    private double weight;  // Measured in kilograms (kg)
    private double height;  // Measured in inches.
    Doctor[] doctors = (Doctor[]) User.getRegisteredDoctors();

    Feedback feedback = new Feedback();
    Feedback[] feedbacksArray = feedback.getFeedbacks();
    int feedbackCount = Feedback.getNoOfFeedbacks();
    AppointmentManager am = new AppointmentManager();
    ArrayList<Appointment> appointments = am.getAppointments();

    public int getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(int heartRate) {
        this.heartRate = heartRate;
    }

    public String getBloodPressure() {
        return bloodPressure;
    }

    public void setBloodPressure(String bloodPressure) {
        this.bloodPressure = bloodPressure;
    }

    public double getBodyTemperature() {
        return bodyTemperature;
    }

    public void setBodyTemperature(double bodyTemperature) {
        this.bodyTemperature = bodyTemperature;
    }

    public int getRespiratoryRate() {
        return respiratoryRate;
    }

    public void setRespiratoryRate(int respiratoryRate) {
        this.respiratoryRate = respiratoryRate;
    }

    public int getBloodSugarLevel() {
        return bloodSugarLevel;
    }

    public void setBloodSugarLevel(int bloodSugarLevel) {
        this.bloodSugarLevel = bloodSugarLevel;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void uploadVitals() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Heart Rate (BPM): ");
        this.heartRate = scanner.nextInt();

        System.out.print("Enter Blood Pressure (Systolic/Diastolic): ");
        scanner.nextLine();
        this.bloodPressure = scanner.nextLine();

        System.out.print("Enter Body Temperature (°F): ");
        this.bodyTemperature = scanner.nextDouble();

        System.out.print("Enter Respiratory Rate (breaths per minute): ");
        this.respiratoryRate = scanner.nextInt();

        System.out.print("Enter Blood Sugar Level (mg/dL): ");
        this.bloodSugarLevel = scanner.nextInt();

        System.out.print("Enter Weight (kg): ");
        this.weight = scanner.nextDouble();

        System.out.print("Enter Height (inches): ");
        this.height = scanner.nextDouble();

        System.out.println("\n\tYour Health Data uploaded Successfully\n");
    }

    public void displayVitals() {
        System.out.println("\n--- Uploaded Vitals ---");
        System.out.println("Heart Rate: " + heartRate + " BPM");
        System.out.println("Blood Pressure: " + bloodPressure);
        System.out.println("Body Temperature: " + bodyTemperature + " °F");
        System.out.println("Respiratory Rate: " + respiratoryRate + " breaths/min");
        System.out.println("Blood Sugar Level: " + bloodSugarLevel + " mg/dL");
        System.out.println("Weight: " + weight + " kg");
        System.out.println("Height: " + height + " inches");
    }

    public void feedbacksCount(int[] counter, boolean isCount) {
        if (!isCount) {
            System.out.println("\nTotal Feedbacks: " + counter[0] + "\n");
        }
        for (int i = 0; i < feedbackCount; i++) {
            if (feedbacksArray[i].getPatientID() == this.getUnique_id()) {
                if (isCount) {
                    counter[0]++;
                }else {
                    System.out.println("Doctor Name: " + feedbacksArray[i].getDoctorName());
                    System.out.println("Doctor Notes: " + feedbacksArray[i].getNotes() + "\n");
                }
            }
        }
    }

    public void viewFeedbacks() {
        int[] counter = new int[1];
        feedbacksCount(counter,true);
        feedbacksCount(counter, false);
    }

    public boolean isValidID(long id) {
        for (int i = 0; i < User.getNoOfDoctors(); i++) {
            if (doctors[i].getUnique_id() == id) {
                return true;
            }
        }
        return false;
    }

    public void scheduleAppointment() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter date of appointment (yyyy-MM-dd): ");
        String date = scanner.nextLine();

        LocalDate appointmentDate = LocalDate.parse(date);

        System.out.print("Enter Doctor ID: ");
        long doctorID = scanner.nextLong();
        boolean validId = isValidID(doctorID);

        long patientID = this.getUnique_id();
        String status = "Pending";

        if (validId) {
            appointments.add(new Appointment(appointmentDate, doctorID, patientID, status));
            System.out.println("Appointment scheduled successfully! You will get update" +
                    "on appointment you booked by manager in short time\n");
        }else {
            System.out.println("You have entered incorrect Doctor Id. Plz enter correct one");
        }
    }
}
